#' convertString
#'
#' converts a string to pig latin
#'
#' @param string this is the string to be converted into pig latin
#'
#' @export
#'
#' @return this returns a string in pig latin
#'
#' @family RPigLatin
#'
#'


convertString = function(input)
{
  require(stringr)
  end = substr(input, nchar(input), nchar(input))
  punctuationAdjust = FALSE
  if(end == "." || end == "?" || end == "," || end == "!")
  {
    punctuationAdjust=TRUE
    input = substr(input,1, nchar(input)-1)
  }
  capitalized = FALSE
  if(stringr::str_detect(substr(input, 1, 1),"[[:upper:]]"))
  {
    capitalized=TRUE
    input=stringr::str_to_lower(input)
  }
  index = -1
  for(i in 1:nchar(input))
  {
    if(isVowel(substr(input,i,i))==TRUE)
    {
      index = i
      break
    }
  }
  if(index==-1)
  {
    return(input)
  }
  if(punctuationAdjust && capitalized)
  {
    return(paste(str_to_upper(substr(input, index, index)),substr(input, index+1, nchar(input)),substr(input,1,index-1),"ay",end,sep=""))
  }else if(punctuationAdjust)
  {
    return(paste(substr(input, index, nchar(input)),substr(input,1,index-1),"ay",end,sep=""))
  }
  else if(capitalized)
  {
    return(paste(str_to_upper(substr(input, index, index)),substr(input, index+1, nchar(input)),substr(input,1,index-1),"ay",sep=""))
  }else {
  return(paste(substr(input, index, nchar(input)),substr(input,1,index-1),"ay", sep=""))
  }
}





