#' PigLatin
#'
#' Translates a string into pig latin
#'
#' @param string This is the input, which is translated into pig latin.
#'
#' @export
#'
#' @return this returns a list of strings
#'
#' @family RPigLatin
#'
#'

PigLatin = function(string)
{
 require(stringr)
 words = strsplit(string, " ")[[1]]
 newWords = as.vector(sapply(words, convertString))
 str = paste0(noquote(newWords),collapse=" ")
 return(str)
}
