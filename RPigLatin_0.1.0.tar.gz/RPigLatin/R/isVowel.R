#' isVowel
#'
#' Checks if the character passed is a vowel
#'
#' @param char This is the input, which is lexed into a list of strings
#'
#' @export
#'
#' @return this returns a boolean signifying true if the character is a vowel and false otherwise.
#'
#' @family RPigLatin
#'
#'


isVowel = function(x)
{
  if(x == "a" || x=="e" || x == "i" || x == "o" || x == "u" || x == "A" || x=="E" || x == "I" || x == "O" || x == "U")
  {
    return(TRUE)
  }
  else return(FALSE)
}
