## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(RPigLatin)
require(stringr)


## -----------------------------------------------------------------------------
PigLatin("Your hovercraft is full of eels. Please, sir, it's distressing many of the other guests at the Grand Hotel.")

